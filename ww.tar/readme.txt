Name:Zhengyang Ling, Yanchen Jing
Netid:ZL351 yj301
Test strategy:  Because we use different codes base on different situations, we give each situation an example in order to test.
For example, if we need to wrap something to 3, we will test "abc", "a", "ab ba", "sada", "a c d", and "a \n ab  \n\n\n a". 
The number of the situation is limit. For a single input, we can divide the situation into three kinds. '\n', ' ', and letter. For ' ', we only need to eliminate all of this. 
For '\n', we need to see what is the next non-' ' input. If the next non-' ' input is \n, then we need to write '\n\n'. If the next non-' ' input is a letter, then we ignore the \n or just treat it as white space. 
For the letter, we will read until '\n' or white space. Storing it into the buf, then use the length of the buf to judge whether put it into the buffer for the line. 
If add this length is not enough, then we will read the next word. If add this length is equal to width, then add this word into the line and output. 
If add this length is bigger than the width, then we output this line and put the word into the next line. And when we put it into the next line, we need to judge whether this word is too long. 
Thus, we will give each situation an example to test.
For the second part, we test several situations;
For the normal dir, when we get into the dir, we just find out whether it is a file or a dir. If it is a dir, then we just omit it.
If it is a file, we will find if it is already in the format of "warp."
if it is already in this format, then we will overwrite it.
If it is not there, we will create a new file and modify it to fix in our situation.
If our input is '.', then we will create a modified file for each file.
And if our input is "..", then we will go to its parent dir to create a modified file for each file in the parent dir.