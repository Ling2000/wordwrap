#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <ctype.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <dirent.h>

#ifndef DEBUG
#define DEBUG 0
#endif

int isdir(char *name) {
	struct stat data;

	int err = stat(name, &data);

	// should confirm err == 0
	if (err) {
		perror(name);  // print error message
		return 0;
	}

	if (S_ISDIR(data.st_mode)) {
		// S_ISDIR macro is true if the st_mode says the file is a directory
		// S_ISREG macro is true if the st_mode says the file is a regular file

		return 1;
	}

	return 0;
}


int extendTxt(unsigned width,int fd,int* x)
{
	int youlailangfeide;
	int bytes;
	char b[1];
	char c[1];
	char *bufforr= malloc(sizeof(char) * (width+3));
	bufforr[0]='\0';
	while ((bytes = read(fd, b, 1)) > 0) {
		char *buf= malloc(sizeof(char) * (width+3));
		if(c[0]=='\n'){
			if(b[0]=='\n'){
				strcat(bufforr,"\n\n\0");
				youlailangfeide=write(1, bufforr, strlen(bufforr));
				if (youlailangfeide==-1) {
					perror("write error");
				}
				bufforr[0]='\0';
				bytes=read(fd, b, 1);
				if(bytes<=0) break;
			}
			else if(b[0]==' '){
				while (b[0]==' ') {
					bytes=read(fd, b, 1);
					if(bytes<=0) break;
				}
				if(b[0]=='\n'){
					strcat(bufforr,"\n\n\0");
					youlailangfeide=write(1, bufforr, strlen(bufforr));
					if (youlailangfeide==-1) {
						perror("write error");
					}
					bufforr[0]='\0';
					bytes=read(fd, b, 1);
					if(bytes<=0) break;
				}
			}
		}


		while (b[0]==' ') {
			bytes=read(fd, b, 1);
			if(bytes<=0) break;
		}
		int i=0;
		int size=width;
		while (b[0]!='\n'&&b[0]!=' '&&bytes>0) {
			if (i==size) {
				*x=1;
				size++;
				char *p = realloc(buf, sizeof(char) * size);
				buf=p;
				}
			buf[i]=b[0];
			i++;
			bytes=read(fd, b, 1);
		}
		char *p = realloc(buf, sizeof(char) * size+2);
		buf=p;
		if(b[0]=='\n'){
			c[0]='\n';
		}
		else{
			c[0]=' ';
		}
		buf[i]='\0';

		if (strlen(buf)>=width&&strlen(bufforr)==0) {
			strcat(buf,"\n\0");
			youlailangfeide=write(1, buf, strlen(buf));
			if (youlailangfeide==-1) {
				perror("write error");
			}
		}
		else{
		if(strlen(buf)+strlen(bufforr)+1>width){
			strcat(bufforr,"\n\0");
			youlailangfeide=write(1, bufforr, strlen(bufforr));
			if (youlailangfeide==-1) {
				perror("write error");
			}
			bufforr[0]='\0';
			if (strlen(buf)>width&&strlen(bufforr)==0) {
				strcat(buf,"\n\0");
				youlailangfeide=write(1, buf, strlen(buf));
				if (youlailangfeide==-1) {
					perror("write error");
				}
			}
			else{
				strcat(bufforr,buf);
			}
		}
		else if(strlen(buf)+strlen(bufforr)+1==width){
			if(strlen(bufforr)==0){
				strcat(bufforr,buf);
			}
			else{
				strcat(bufforr," ");
				strcat(bufforr,buf);
			}
			if (c[0]!='\n') {
				strcat(bufforr,"\n\0");
			}
			else{
				strcat(bufforr,"\0");
			}

			youlailangfeide=write(1, bufforr, strlen(bufforr));
			if (youlailangfeide==-1) {
				perror("write error");
			}
			bufforr[0]='\0';
		}
		else{
			if(strlen(bufforr)==0){
				strcat(bufforr,buf);
			}
			else{
				strcat(bufforr," ");
				strcat(bufforr,buf);
			}
		}
	}
  	if (bytes < 0) {
			perror("Read error");
  	}
		free(buf);
	}
	youlailangfeide=write(1, bufforr, strlen(bufforr));
	if (youlailangfeide==-1) {
		perror("write error");
	}
	free(bufforr);
	youlailangfeide=write(1,"\n", 1);
	if (youlailangfeide==-1) {
		perror("write error");
	}
  close(fd);
	return 0;
}

int extendTXT(unsigned width,char* fileName,int* x,char* dir)
{
	char *fN= malloc(sizeof(char) * (strlen(fileName)+strlen(dir)+3));
	fN[0]='\0';
	strcat(fN,dir);
	strcat(fN,"/");
	strcat(fN,fileName);
	int youlailangfeide;
	int fd,fd2,bytes;
  fd = open(fN, O_RDWR);
	char *outfileName= malloc(sizeof(char) * (strlen(fileName)+6));
	outfileName[0]='w';
	outfileName[1]='r';
	outfileName[2]='a';
	outfileName[3]='p';
	outfileName[4]='.';
	int i;
	for (i = 0; i < strlen(fileName); i++){
    outfileName[i+5]=fileName[i];
  }
	outfileName[i+5]='\0';
	char *ofN= malloc(sizeof(char) * (strlen(outfileName)+strlen(dir)+6));
	ofN[0]='\0';
	strcat(ofN,dir);
	strcat(ofN,"/");
	strcat(ofN,outfileName);
  	umask(0000);
	fd2 = open(ofN, O_WRONLY|O_CREAT|O_TRUNC,0666);
	char b[1];
	char c[1];
	if (fd == -1) {
		perror(fileName);
		return 1;
	}
	char *bufforr= malloc(sizeof(char) * (width+3));
	bufforr[0]='\0';
	while ((bytes = read(fd, b, 1)) > 0) {
		char *buf= malloc(sizeof(char) * (width+1));
		if(c[0]=='\n'){
			if(b[0]=='\n'){
				strcat(bufforr,"\n\n\0");
				youlailangfeide=write(fd2, bufforr, strlen(bufforr));
				if (youlailangfeide==-1) {
					perror("write error");
				}
				bufforr[0]='\0';
				bytes=read(fd, b, 1);
				if(bytes<=0) break;
			}
			else if(b[0]==' '){
				while (b[0]==' ') {
					bytes=read(fd, b, 1);
					if(bytes<=0) break;
				}
				if(b[0]=='\n'){
					strcat(bufforr,"\n\n\0");
					youlailangfeide=write(fd2, bufforr, strlen(bufforr));
					if (youlailangfeide==-1) {
					perror("write error");
					}
					bufforr[0]='\0';
					bytes=read(fd, b, 1);
					if(bytes<=0) break;
				}
			}
		}


		while (b[0]==' ') {
			bytes=read(fd, b, 1);
			if(bytes<=0) break;
		}
		int i=0;
		int size=width;
		while (b[0]!='\n'&&b[0]!=' '&&bytes>0) {
			if (i==size) {
				*x=1;
				size++;
				char *p = realloc(buf, sizeof(char) * size);
				buf=p;
				}
			buf[i]=b[0];
			i++;
			bytes=read(fd, b, 1);
		}
		if(b[0]=='\n'){
			c[0]='\n';
		}

		buf[i]='\0';

		if (strlen(buf)>=width&&strlen(bufforr)==0) {
			strcat(buf,"\n\0");
			youlailangfeide=write(fd2, bufforr, strlen(bufforr));
			if (youlailangfeide==-1) {
				perror("write error");
				}
		}
		else{
		if(strlen(buf)+strlen(bufforr)+1>width){
			strcat(bufforr,"\n\0");
			youlailangfeide=write(fd2, bufforr, strlen(bufforr));
			if (youlailangfeide==-1) {
				perror("write error");
			}
			bufforr[0]='\0';
			if (strlen(buf)>width&&strlen(bufforr)==0) {
				strcat(buf,"\n\0");
				youlailangfeide=write(fd2, bufforr, strlen(bufforr));
				if (youlailangfeide==-1) {
				perror("write error");
				}
			}
			else{
				strcat(bufforr,buf);
			}
		}
		else if(strlen(buf)+strlen(bufforr)+1==width){
			if(strlen(bufforr)==0){
				strcat(bufforr,buf);
			}
			else{
				strcat(bufforr," ");
				strcat(bufforr,buf);
			}
			strcat(bufforr,"\n\0");
			youlailangfeide=write(fd2, bufforr, strlen(bufforr));
			if (youlailangfeide==-1) {
				perror("write error");
				}
			bufforr[0]='\0';
		}
		else{
			if(strlen(bufforr)==0){
				strcat(bufforr,buf);
			}
			else{
				strcat(bufforr," ");
				strcat(bufforr,buf);
			}
		}
	}
  	if (bytes < 0) {
			perror("Read error");
  	}
		free(buf);
	}
	youlailangfeide=write(fd2, bufforr, strlen(bufforr));
		if (youlailangfeide==-1) {
				perror("write error");
			}
	free(bufforr);
	free(outfileName);
	free(fN);
	free(ofN);
  close(fd);
	close(fd2);
	return 0;
}


int extendFile(unsigned width,char* dir,int* x){
	*x=0;
	DIR *dirp = opendir(dir);
	struct dirent *de;
	if(dir == NULL){
		perror(dir);
	}
	while((de = readdir(dirp))!=NULL){
		if(de->d_type==8){
			if((de->d_name[0]!='w' && de->d_name[1]!='r' && de->d_name[2]!='a' && de->d_name[3]!='p' && de->d_name[4]!='.')&& de->d_name[0]!='.'){
  				extendTXT(width,de->d_name,x,dir);
			}
		}
	}
	closedir(dirp);
	return 0;
}

int main(int argc, char **argv) {
	if (argc==2){
		int x=0;
		extendTxt(atoi(argv[1]),0, &x);
		if(x==1){
			return EXIT_FAILURE;
		}
		return EXIT_SUCCESS;

	}
  if (argc==3){
    if(!isdir(argv[2])){
			int x=0;
			int fd;
			fd = open(argv[2], O_RDWR);
			if (fd == -1) {
				perror(argv[2]);
				return 1;
			}
        extendTxt(atoi(argv[1]), fd, &x);
			if(x==1){
				return EXIT_FAILURE;
			}
      return EXIT_SUCCESS;
    }
    else {
    	int x = 0;
		extendFile(atoi(argv[1]),argv[2], &x);
    }
  }
  return EXIT_FAILURE;

}
